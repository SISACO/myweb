from .models import AlumniInfo
from typing import List
from django.db.models import Max 


def process_alumni_batches() -> List[dict]:
    batch_information = []

    # Fetch the latest graduation year in the database
    latest_graduation_year = AlumniInfo.objects.aggregate(latest_year=Max('graduation_year'))['latest_year']

    # Set the threshold for creating a new batch
    threshold_year = latest_graduation_year + 1 if latest_graduation_year is not None else 2020

    # Set the special year for a separate batch
    special_year = threshold_year + 10

    # Fetch unique graduation years
    graduation_years = AlumniInfo.objects.values_list('graduation_year', flat=True).distinct().order_by('graduation_year')

    # Process batches
    for graduation_year in graduation_years:
        start_year = graduation_year
        end_year = graduation_year + 9  # End year is 10 years after start year

        # If the start year is before the threshold, create a new batch with a different range
        if start_year < threshold_year:
            start_year = threshold_year - 10  # Adjust the start year
            end_year = start_year + 9  # End year is 10 years after the new start year

        # Fetch alumni data for the current batch
        alumni_batch = AlumniInfo.objects.filter(graduation_year__range=(start_year, end_year))

        # Prepare batch information
        batch_info = {
            'batch_range': f"{start_year}-{end_year}",
            'start_year': start_year,
            'end_year': end_year,
            'alumni_list': [{'name': alumnus.full_name, 'graduation_year': alumnus.graduation_year} for alumnus in alumni_batch]
        }

        batch_information.append(batch_info)

    # Create a special batch for the year after the latest graduation year
    special_batch_start_year = special_year - 10
    special_batch_end_year = special_year - 1
    special_batch = {
        'batch_range': f"{special_batch_start_year}-{special_batch_end_year}",
        'start_year': special_batch_start_year,
        'end_year': special_batch_end_year,
        'alumni_list': []
    }
    batch_information.append(special_batch)

    return batch_information
