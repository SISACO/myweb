from django import forms
from .models import AlumniInfo

class AlumniInfoForm(forms.ModelForm):
    class Meta:
        model = AlumniInfo
        fields = [
            'full_name',
            'department',
            'graduation_year',
            'contact_email',
            'Native_Place',
            'job_title',
            'District',
            'higher_education',
            'company',
            'website',
            'industry',
            'linkedin_profile',
            'photo',
            'description'
        ]